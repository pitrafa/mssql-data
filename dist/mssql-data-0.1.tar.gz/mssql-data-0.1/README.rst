==========
MsSQL Data
==========

Quick start
-----------

1. Add "data" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'data',
    ]
